<?php

require_once __DIR__ . '/i18n.php';
load_language();

function h(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function format_date(?string $date): string {
    if (!$date) {
        return '—';
    }
    $timestamp = strtotime($date);
    if (!$timestamp) {
        return '—';
    }
    return current_language() === 'en' ? date('d M Y', $timestamp) : date('d-m-Y', $timestamp);
}

function greeting_for_time(): string {
    $hour = (int) date('G');
    return match (true) {
        $hour < 10 => t('home.greeting_morning'),
        $hour < 18 => t('home.greeting_day'),
        default => t('home.greeting_evening'),
    };
}

function format_long_date(): string {
    $weekdaysDa = ['søndag', 'mandag', 'tirsdag', 'onsdag', 'torsdag', 'fredag', 'lørdag'];
    $monthsDa = ['', 'januar', 'februar', 'marts', 'april', 'maj', 'juni', 'juli', 'august', 'september', 'oktober', 'november', 'december'];
    $weekdaysEn = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    $monthsEn = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    $w = (int) date('w');
    $d = (int) date('j');
    $m = (int) date('n');

    if (current_language() === 'en') {
        return $weekdaysEn[$w] . ', ' . $monthsEn[$m] . ' ' . $d;
    }
    return $weekdaysDa[$w] . ' den ' . $d . '. ' . $monthsDa[$m];
}

function status_badge_class(string $status): string {
    return match ($status) {
        'Godkendt' => 'badge badge-success',
        'Til godkendelse' => 'badge badge-warning',
        'Afvist', 'Udgået' => 'badge badge-danger',
        default => 'badge badge-neutral',
    };
}

function status_label(string $status): string {
    return t('status.' . $status);
}

function case_status_label(string $status): string {
    return t('case_status.' . $status);
}

function severity_label(?string $severity): string {
    return $severity ? t('severity.' . $severity) : '—';
}

function type_label(string $type): string {
    return t('type.' . $type);
}

function category_label(string $category): string {
    return list_value_label('document_category', $category);
}

function role_label(string $role): string {
    return t('role.' . $role);
}

function query_merge(array $overrides): string {
    $params = $_GET;
    foreach ($overrides as $k => $v) {
        if ($v === null) {
            unset($params[$k]);
        } else {
            $params[$k] = $v;
        }
    }
    return http_build_query($params);
}

function sort_header_link(string $column, string $currentSort, string $currentDir): array {
    $active = $currentSort === $column;
    $nextDir = ($active && $currentDir === 'asc') ? 'desc' : 'asc';
    $icon = $active ? ($currentDir === 'asc' ? 'ti-arrow-up' : 'ti-arrow-down') : 'ti-arrows-sort';
    $href = basename($_SERVER['PHP_SELF']) . '?' . query_merge(['sort' => $column, 'dir' => $nextDir]);
    return ['href' => $href, 'icon' => $icon, 'active' => $active];
}

function remove_array_filter_href(string $param, array $current, string $value): string {
    $remaining = array_values(array_diff($current, [$value]));
    return basename($_SERVER['PHP_SELF']) . '?' . query_merge([$param => $remaining ?: null]);
}

function clear_filter_href(string $param): string {
    return basename($_SERVER['PHP_SELF']) . '?' . query_merge([$param => null]);
}

function clear_all_filters_href(array $params): string {
    $overrides = [];
    foreach ($params as $p) {
        $overrides[$p] = null;
    }
    return basename($_SERVER['PHP_SELF']) . '?' . query_merge($overrides);
}

function render_active_filters(array $chips, string $clearAllHref): void {
    if (!$chips) {
        return;
    }
    ?>
    <div class="active-filters">
        <?php foreach ($chips as $chip): ?>
            <a class="filter-chip" href="<?= h($chip['href']) ?>"><?= h($chip['label']) ?> <i class="ti ti-x" aria-hidden="true"></i></a>
        <?php endforeach; ?>
        <a class="filter-clear-all" href="<?= h($clearAllHref) ?>"><?= h(t('filter.clear_all')) ?></a>
    </div>
    <?php
}

function hidden_inputs_for_query(array $exclude = []): void {
    foreach ($_GET as $key => $value) {
        if (in_array($key, $exclude, true)) {
            continue;
        }
        if (is_array($value)) {
            foreach ($value as $v) {
                echo '<input type="hidden" name="' . h($key) . '[]" value="' . h($v) . '">';
            }
        } else {
            echo '<input type="hidden" name="' . h($key) . '" value="' . h($value) . '">';
        }
    }
}

function render_th_controls(
    string $label,
    string $column,
    string $currentSort,
    string $currentDir,
    ?string $filterParam = null,
    array $filterOptions = [],
    array $filterSelected = [],
    ?callable $filterLabelFn = null,
    string $filterTitle = ''
): void {
    $s = sort_header_link($column, $currentSort, $currentDir);
    $hasFilter = $filterParam !== null;
    $filterActive = $hasFilter && $filterSelected;
    ?>
    <div class="th-inner">
        <a href="<?= h($s['href']) ?>" class="th-label <?= $s['active'] ? 'th-active' : '' ?>" title="<?= h($label) ?>"><?= h($label) ?></a>
        <span class="th-icons">
            <a href="<?= h($s['href']) ?>" class="<?= $s['active'] ? 'th-active' : '' ?>"><i class="ti <?= h($s['icon']) ?>" aria-hidden="true"></i></a>
            <?php if ($hasFilter): ?>
                <span class="th-divider"></span>
                <details class="col-filter">
                    <summary><i class="ti <?= $filterActive ? 'ti-filter-filled filter-active' : 'ti-filter' ?>" aria-hidden="true"></i></summary>
                    <div class="filter-dropdown">
                        <div class="filter-dropdown-title"><?= h($filterTitle) ?></div>
                        <form method="get">
                            <?php hidden_inputs_for_query([$filterParam]); ?>
                            <div class="filter-dropdown-options">
                                <?php foreach ($filterOptions as $opt): ?>
                                    <label><input type="checkbox" name="<?= h($filterParam) ?>[]" value="<?= h($opt) ?>" <?= in_array($opt, $filterSelected, true) ? 'checked' : '' ?>> <?= h($filterLabelFn($opt)) ?></label>
                                <?php endforeach; ?>
                            </div>
                            <div class="filter-dropdown-actions">
                                <?php if ($filterActive): ?>
                                    <a href="<?= h(clear_filter_href($filterParam)) ?>" class="filter-clear-link"><?= h(t('filter.clear')) ?></a>
                                <?php endif; ?>
                                <button type="submit"><?= h(t('filter.apply')) ?></button>
                            </div>
                        </form>
                    </div>
                </details>
            <?php endif; ?>
        </span>
    </div>
    <?php
}

function get_list_items_cached(string $listType, int $organizationId): array {
    static $cache = [];
    $key = $listType . ':' . $organizationId;
    if (!isset($cache[$key])) {
        $db = get_db();
        $stmt = $db->prepare('SELECT * FROM list_items WHERE list_type = ? AND organization_id = ? ORDER BY sort_order, id');
        $stmt->execute([$listType, $organizationId]);
        $cache[$key] = $stmt->fetchAll();
    }
    return $cache[$key];
}

function list_active_values(string $listType): array {
    $user = current_user();
    $orgId = $user['organization_id'] ?? 0;
    $items = get_list_items_cached($listType, $orgId);
    return array_values(array_column(array_filter($items, fn($i) => (int) $i['active'] === 1), 'label_da'));
}

function list_value_label(string $listType, string $valueDa): string {
    $user = current_user();
    $orgId = $user['organization_id'] ?? 0;
    $items = get_list_items_cached($listType, $orgId);
    foreach ($items as $item) {
        if ($item['label_da'] === $valueDa) {
            return (current_language() === 'en' && $item['label_en']) ? $item['label_en'] : $item['label_da'];
        }
    }
    return $valueDa;
}

function list_type_label(string $listType): string {
    return t('lists.type.' . $listType);
}

function seed_default_lists(int $organizationId): void {
    $db = get_db();
    $defaults = [
        'document_category' => [
            ['Procedure', 'Procedure'],
            ['Arbejdsinstruktion', 'Work instruction'],
            ['Formular', 'Form'],
            ['Politik', 'Policy'],
        ],
        'record_type' => [
            ['Kompetencematrix', 'Competence matrix'],
            ['Kalibreringsbevis', 'Calibration certificate'],
            ['Mødereferat', 'Meeting minutes'],
            ['Træningsbevis', 'Training certificate'],
            ['Ledelsens evaluering', 'Management review'],
        ],
        'risk_category' => [
            ['Strategisk', 'Strategic'],
            ['Operationel', 'Operational'],
            ['Leverandør', 'Supplier'],
            ['IT', 'IT'],
            ['Andet', 'Other'],
        ],
        'supplier_category' => [
            ['Vare', 'Goods'],
            ['Service', 'Service'],
            ['Underleverandør af produktion', 'Production subcontractor'],
            ['Rådgivning', 'Consulting'],
            ['Andet', 'Other'],
        ],
    ];

    $stmt = $db->prepare('INSERT INTO list_items (organization_id, list_type, label_da, label_en, sort_order) VALUES (?, ?, ?, ?, ?)');
    foreach ($defaults as $listType => $items) {
        foreach ($items as $i => $pair) {
            $stmt->execute([$organizationId, $listType, $pair[0], $pair[1], $i + 1]);
        }
    }
}

function can_edit_documents(array $user): bool {
    return in_array($user['role'], ['admin', 'editor'], true);
}

function can_approve_documents(array $user): bool {
    return in_array($user['role'], ['admin', 'approver'], true);
}

function can_manage_cases(array $user): bool {
    return in_array($user['role'], ['admin', 'editor'], true);
}

function can_manage_records(array $user): bool {
    return in_array($user['role'], ['admin', 'editor'], true);
}

function can_manage_audits(array $user): bool {
    return in_array($user['role'], ['admin', 'editor'], true);
}

function can_manage_equipment(array $user): bool {
    return in_array($user['role'], ['admin', 'editor'], true);
}

function mismatch_class(?int $systemCount, ?int $manualCount): string {
    if ($manualCount === null) {
        return 'badge badge-neutral';
    }
    return $systemCount === $manualCount ? 'badge badge-success' : 'badge badge-danger';
}

function mismatch_label(?int $systemCount, ?int $manualCount): string {
    if ($manualCount === null) {
        return '—';
    }
    return $systemCount === $manualCount ? t('mgmtreview.match') : t('mgmtreview.mismatch');
}

function can_manage_risks(array $user): bool {
    return in_array($user['role'], ['admin', 'editor'], true);
}

function is_gqar(array $user): bool {
    return $user['role'] === 'gqar';
}

function deny_gqar(array $user): void {
    if (is_gqar($user)) {
        http_response_code(403);
        echo t('error.forbidden');
        exit;
    }
}

function can_manage_customers(array $user): bool {
    return in_array($user['role'], ['admin', 'editor'], true);
}

function can_manage_suppliers(array $user): bool {
    return in_array($user['role'], ['admin', 'editor'], true);
}

function supplier_category_options(): array {
    return list_active_values('supplier_category');
}

function supplier_category_label(string $category): string {
    return list_value_label('supplier_category', $category);
}

function supplier_status_label(string $status): string {
    return t('supplier_status.' . $status);
}

function supplier_status_class(string $status): string {
    return match ($status) {
        'Godkendt' => 'badge badge-success',
        'Under vurdering' => 'badge badge-warning',
        'Afvist', 'Udfaset' => 'badge badge-danger',
        default => 'badge badge-neutral',
    };
}

function risk_score(int $probability, int $consequence): int {
    return $probability * $consequence;
}

function risk_band(int $score): string {
    return match (true) {
        $score >= 15 => 'Kritisk',
        $score >= 10 => 'Høj',
        $score >= 5 => 'Mellem',
        default => 'Lav',
    };
}

function risk_band_label(string $band): string {
    return t('risk_band.' . $band);
}

function risk_band_class(string $band): string {
    return match ($band) {
        'Kritisk' => 'badge badge-danger',
        'Høj' => 'badge badge-risk-high',
        'Mellem' => 'badge badge-warning',
        default => 'badge badge-success',
    };
}

function risk_category_label(string $category): string {
    return list_value_label('risk_category', $category);
}

function risk_status_label(string $status): string {
    return t('risk_status.' . $status);
}

function risk_status_class(string $status): string {
    return match ($status) {
        'Lukket' => 'badge badge-success',
        'Under behandling' => 'badge badge-warning',
        default => 'badge badge-neutral',
    };
}

function equipment_criticality_label(string $value): string {
    return t('equipment_criticality.' . $value);
}

function equipment_criticality_class(string $value): string {
    return $value === 'Kritisk' ? 'badge badge-danger' : 'badge badge-neutral';
}

function equipment_status_label(string $value): string {
    return t('equipment_status.' . $value);
}

function equipment_status_class(string $value): string {
    return $value === 'Aktiv' ? 'badge badge-success' : 'badge badge-neutral';
}

function audit_type_label(string $value): string {
    return t('audit_type.' . $value);
}

function equipment_outcome_label(string $value): string {
    return t('equipment_outcome.' . $value);
}

function equipment_outcome_class(string $value): string {
    return match ($value) {
        'Ikke godkendt' => 'badge badge-danger',
        'Justeret' => 'badge badge-warning',
        default => 'badge badge-success',
    };
}

function audit_status_label(string $status): string {
    return t('audit_status.' . $status);
}

function audit_status_class(string $status): string {
    return match ($status) {
        'Gennemført' => 'badge badge-success',
        'Aflyst' => 'badge badge-danger',
        default => 'badge badge-neutral',
    };
}

function record_type_label(string $type): string {
    return list_value_label('record_type', $type);
}

function record_type_defaults(string $type): array {
    return match ($type) {
        'Kompetencematrix' => ['retention' => 3, 'months' => 3],
        'Kalibreringsbevis' => ['retention' => 5, 'months' => 12],
        'Mødereferat' => ['retention' => 5, 'months' => 0],
        'Træningsbevis' => ['retention' => 5, 'months' => 12],
        default => ['retention' => 5, 'months' => 0],
    };
}

function case_status_class(string $status): string {
    return match ($status) {
        'Lukket' => 'badge badge-success',
        'Handling igangsat' => 'badge badge-warning',
        default => 'badge badge-neutral',
    };
}

function severity_class(?string $severity): string {
    return match ($severity) {
        'Høj' => 'badge badge-danger',
        'Mellem' => 'badge badge-warning',
        'Lav' => 'badge badge-success',
        default => 'badge badge-neutral',
    };
}

function render_header(string $title): void {
    $user = current_user();
    ?>
    <!DOCTYPE html>
    <html lang="<?= h(current_language()) ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= h($title) ?> - <?= h(t('brand.name')) ?></title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/dist/tabler-icons.min.css">
        <link rel="stylesheet" href="css/style.css?v=27">
    </head>
    <body>
    <header class="topbar">
        <a href="<?= $user ? 'home.php' : 'login.php' ?>" class="brand">
            <img src="css/logo.png?v=2" alt="QMSPartner - Quality Management System" class="brand-logo">
        </a>
        <nav>
            <?php if ($user): ?>
                <span class="user-tag"><?= h($user['name']) ?> (<?= h(role_label($user['role'])) ?>)</span>
                <a href="index.php"><?= h(t('nav.documents')) ?></a>
                <a href="cases.php"><?= h(t('nav.cases')) ?></a>
                <a href="audits.php"><?= h(t('nav.audits')) ?></a>
                <?php if (!is_gqar($user)): ?>
                    <a href="records.php"><?= h(t('nav.records')) ?></a>
                    <a href="equipment.php"><?= h(t('nav.equipment')) ?></a>
                    <a href="risks.php"><?= h(t('nav.risks')) ?></a>
                    <a href="suppliers.php"><?= h(t('nav.suppliers')) ?></a>
                    <a href="customers.php"><?= h(t('nav.customers')) ?></a>
                <?php endif; ?>
                <?php if ($user['role'] === 'admin'): ?>
                    <a href="users.php"><?= h(t('nav.users')) ?></a>
                    <a href="lists.php"><?= h(t('nav.lists')) ?></a>
                <?php endif; ?>
                <a href="help.php"><?= h(t('nav.help')) ?></a>
                <a href="logout.php"><?= h(t('nav.logout')) ?></a>
            <?php endif; ?>
            <span class="lang-switch">
                <?php foreach (AVAILABLE_LANGUAGES as $code => $label): ?>
                    <a href="lang.php?lang=<?= h($code) ?>" class="<?= current_language() === $code ? 'lang-active' : '' ?>"><?= strtoupper($code) ?></a>
                <?php endforeach; ?>
            </span>
        </nav>
    </header>
    <main class="container">
    <?php
}

function render_footer(): void {
    ?>
    </main>
    </body>
    </html>
    <?php
}
